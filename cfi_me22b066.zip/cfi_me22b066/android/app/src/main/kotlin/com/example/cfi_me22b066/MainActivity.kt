package com.example.cfi_me22b066

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
