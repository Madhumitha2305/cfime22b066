import 'package:flutter/material.dart';
import 'character.dart';
import 'swapi_service.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Star Wars API',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late Future<List<Character>> characters;

  @override
  void initState() {
    super.initState();
    characters = SwapiService.fetchData('https://swapi.dev/api/people/')
        .then((data) => parseCharacters(data));
  }

  List<Character> parseCharacters(dynamic data) {
    final List<dynamic> results = data['results'];
    return results.map((json) => Character.fromJson(json)).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Star Wars Characters'),
      ),
      body: Column(
        children: [
          Expanded(
            child: FutureBuilder<List<Character>>(
              future: characters,
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  final List<Character> characterList = snapshot.data!;
                  return ListView.builder(
                    itemCount: characterList.length,
                    itemBuilder: (context, index) {
                      final Character character = characterList[index];
                      return ListTile(
                        title: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Birth Year: ${character.birthYear}'),
                            Text('mass: ${character.mass}'),
                            Text('hair_color: ${character.haircolor}'),
                            Text('skin_color: ${character.skincolor}'),
                            Text('homeworld: ${character.homeworld}'),
                            Text('films: ${character.films}'),
                            Text('species: ${character.species}'),
                            Text('vehicles: ${character.vehicles}'),
                            Text('starships: ${character.starships}'),
                            Text('hair_color: ${character.haircolor}'),
                            Text('skin_color: ${character.skincolor}'),
                            Text('homeworld: ${character.homeworld}'),
                            Text('films: ${character.films}'),
                            Text('species: ${character.species}'),
                            Text('vehicles: ${character.vehicles}'),
                            Text('starships: ${character.starships}'),
                            Text('Gender: ${character.gender}'),
                            Divider(
                              color: Colors.grey,
                              thickness: 1,
                              height: 16,
                            ),
                          ],
                        ),

                      );
                    },
                  );
                } else if (snapshot.hasError) {
                  return Center(child: Text('${snapshot.error}'));
                } else {
                  return Center(child: CircularProgressIndicator());
                }
              },
            ),

          )
        ]
      )
    );
  }
}

