class Character {
  final String name;
  final String birthYear;
  final String gender;
  final String mass;
  final String skincolor;
  final String haircolor;
  final List<String> films;
  final String homeworld;
  final List<String> species;
  final List<String> vehicles;
  final List<String> starships;
  // Add more properties as needed

  Character({
    required this.name,
    required this.birthYear,
    required this.gender,
    required this.mass,
    required this.skincolor,
    required this.haircolor,
    required this.films,
    required this.homeworld,
    required this.species,
    required this.vehicles,
    required this.starships,
    // Initialize additional properties here
  });

  factory Character.fromJson(Map<String, dynamic> json) {
    return Character(
      name: json['name'],
      birthYear: json['birth_year'],
      gender: json['gender'],
      mass: json['mass'],
      skincolor: json['skin_color'],
      haircolor: json['hair_color'],
      films: List<String>.from(json['films']),
      homeworld: json['homeworld'],
      species: List<String>.from(json['species']),
      vehicles: List<String>.from(json['vehicles']),
      starships: List<String>.from(json['starships']),
      // Map additional properties from JSON here
    );
  }
}
