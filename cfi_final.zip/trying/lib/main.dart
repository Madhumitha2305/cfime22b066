import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class SwapiService {
  static Future<dynamic> fetchData(String endpoint) async {
    final response = await http.get(Uri.parse('https://swapi.dev/$endpoint'));
    print('Response status code: ${response}');
    print('Response body: ${response.body}');

    if (response.statusCode == 200) {
      print("check1");
      return jsonDecode(response.body);

    } else {
      print("check2");
      throw Exception('Failed to fetch data');
    }
  }
}

class SwapiPage extends StatefulWidget {
  final String section;

  SwapiPage({required this.section});

  @override
  _SwapiPageState createState() => _SwapiPageState();
}

class _SwapiPageState extends State<SwapiPage> {
  late Future<dynamic> swapiData;

  @override
  void initState() {
    super.initState();
    swapiData = SwapiService.fetchData(widget.section);
    print('$swapiData');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('SWAPI - ${widget.section.toUpperCase()}'),
      ),
      body: FutureBuilder<dynamic>(
        future: swapiData,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            print(snapshot.error);
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (snapshot.hasData) {
            final data = snapshot.data;
            if (data != null && data is List) {
              return ListView.builder(
                itemCount: data.length,
                itemBuilder: (context, index) {
                  final item = data[index];
                  return ListTile(
                    title: Text(item['name'] ?? ''),
                    subtitle: Text(item['url'] ?? ''),
                    onTap: () {
                      // Handle item tap if needed
                    },
                  );
                },
              );
            } else {
              return Center(child: Text('Invalid data format'));
            }
          } else {
            return Center(child: Text('No data available'));
          }
        },
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final TextEditingController _inputController = TextEditingController();

  void navigateToSection(BuildContext context, String section) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => SwapiPage(section: section)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('SWAPI Explorer'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _inputController,
              decoration: InputDecoration(
                labelText: 'Enter a SWAPI section (e.g., films, planets)',
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                final input = _inputController.text.trim();
                if (input.isNotEmpty) {
                  navigateToSection(context, input);
                }
              },
              child: Text('Explore'),
            ),
          ],
        ),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    title: 'SWAPI Explorer',
    theme: ThemeData(primarySwatch: Colors.blue),
    home: HomePage(),
  ));
}
