package com.example.trying

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
